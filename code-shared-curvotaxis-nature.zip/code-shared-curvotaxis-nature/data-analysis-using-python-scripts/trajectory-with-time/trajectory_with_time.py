import wrapper as ts
import glob
import array as ar
import numpy as np
t=1300
comx=[]
comy=[]
comz=[]
count=[]
for i in range(t):
    comx.append(0)
    comy.append(0)
    comz.append(0)
    count.append(0)
f=open('trajectory_com_Nshell11_zm_10_ym_120_initial_peak_F_4.dat','a')
for file in glob.glob("datafiles/timestep_000[0][0-9][0].vtu"):
    name=int(file[20:25])
    vesicle=ts.parseDump(file)
    cmx=0.0000
    cmy=0.0000
    cmz=0.0000
    for i in range(vesicle.contents.vlist.contents.n):
        x=vesicle.contents.vlist.contents.vtx[i].contents.x
        y=vesicle.contents.vlist.contents.vtx[i].contents.y
        z=vesicle.contents.vlist.contents.vtx[i].contents.z
        cmx+=x
        cmy+=y
        cmz+=z
    cmx/=vesicle.contents.vlist.contents.n
    cmy/=vesicle.contents.vlist.contents.n
    cmz/=vesicle.contents.vlist.contents.n
    comx[name]=cmx
    comy[name]=cmy
    comz[name]=cmz
    count[name]=1
#print(cmx,cmy,cmz)   
for i in range(t):
    if(count[i]>0):
        f.write('{}, {}, {}, {} \n'.format(i,comx[i],comy[i],comz[i]))

                        
